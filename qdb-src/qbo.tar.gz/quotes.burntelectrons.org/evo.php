<?php

require 'evo_config.php';

define('TIME_PERIOD', 6 * 7);
define('IMAGE_WIDTH', 1280);
define('IMAGE_HEIGHT', 640);
define('IMAGE_PADDING', 10);
define('TEXT_MARGIN', 5);
define('BACKGROUND_COLOR', '255,255,255,0');
define('GRAPH_BACKGROUND_COLOR', '247,247,247,0');
define('BORDER_COLOR', '0,0,0,0');
define('AXIS_COLOR', '0,0,0,0');
define('UP_COLOR', '159,223,127,50');
define('DOWN_COLOR', '223,159,127,50');
define('QUOTES_COLOR', '159,127,223,50');
define('TEXT_COLOR', '0,0,0,0');
define('FONT_SIZE', 3);
define('DATE_FORMAT', 'Y-m-d');

$font_width = imagefontwidth(FONT_SIZE);
$font_height = imagefontheight(FONT_SIZE);

// -1 for axes, -1 for image itself
$graph_width = IMAGE_WIDTH - 2 * IMAGE_PADDING - TEXT_MARGIN - $font_height - 1 - 1;
$graph_height = IMAGE_HEIGHT - 2 * IMAGE_PADDING - TEXT_MARGIN - $font_height - 1 - 1;

$im = imagecreatetruecolor(IMAGE_WIDTH, IMAGE_HEIGHT)
	or die();

mysql_connect(MYSQL_HOSTNAME, MYSQL_USERNAME, MYSQL_PASSWORD)
	or die(mysql_error());

mysql_select_db(MYSQL_DATABASE)
	or die(mysql_error());

$total_seconds = TIME_PERIOD * 24 * 60 * 60;
$query = 'SELECT UNIX_TIMESTAMP() - UNIX_TIMESTAMP(`date`) AS `d`, `code` FROM'
	. ' `' . MYSQL_TABLE_NAME_PREFIX . 'events` ev'
	. ' LEFT JOIN `' . MYSQL_TABLE_NAME_PREFIX . 'event_metadata` md'
	. ' ON ev.`id` = md.`id`'
	. ' WHERE ev.code IN (203,204) AND `name` = "id"'
	. ' AND UNIX_TIMESTAMP(`date`) + ' . $total_seconds . ' > UNIX_TIMESTAMP()';

$result = mysql_query($query)
	or die(mysql_error());

$data = array();
$data['up'] = array();
$data['down'] = array();
$max = 0;
while ($row = mysql_fetch_assoc($result)) {
	$t = ($row['code'] == 203 ? 'up' : 'down');
	$d = $row['d'];
	$x = $graph_width - floor($d / $total_seconds * $graph_width);
	$data[$t][$x]++;
	if ($data[$t][$x] > $max) $max = $data[$t][$x];
}

mysql_free_result($result);

$query = 'SELECT UNIX_TIMESTAMP() - UNIX_TIMESTAMP(`submitted`) FROM'
	. ' `' . MYSQL_TABLE_NAME_PREFIX . 'quotes`'
	. ' WHERE UNIX_TIMESTAMP(`submitted`) + ' . $total_seconds . ' > UNIX_TIMESTAMP()';

$result = mysql_query($query)
	or die(mysql_error());

$qdata = array();
while ($row = mysql_fetch_array($result)) {
	$d = $row[0];
	$x = $graph_width - floor($d / $total_seconds * $graph_width);
	$qdata[$x]++;
}

$qmax = 0;
for ($x = 0; $x < $graph_width; $x++) {
	$qmax += $qdata[$x];
	$qdata[$x] = $qmax;
}

mysql_free_result($result);

mysql_close();

// + 1 for axis
$x_offset = IMAGE_PADDING + TEXT_MARGIN + $font_height + 1;
$y_offset = IMAGE_PADDING;

imagefilledrectangle($im, 0, 0, IMAGE_WIDTH, IMAGE_HEIGHT, get_color($im, BACKGROUND_COLOR));

imagefilledrectangle($im, $x_offset, $y_offset, $x_offset + $graph_width, $y_offset + $graph_height, get_color($im, GRAPH_BACKGROUND_COLOR));

$scale = $graph_height / $max;
draw_graph($im, $data['up'], $scale, IMAGE_WIDTH, IMAGE_HEIGHT, $graph_width, $graph_height, $x_offset, $y_offset, get_color($im, UP_COLOR));
draw_graph($im, $data['down'], $scale, IMAGE_WIDTH, IMAGE_HEIGHT, $graph_width, $graph_height, $x_offset, $y_offset, get_color($im, DOWN_COLOR));

$points = to_points($qdata, $graph_height / $qmax, $graph_width, $graph_height, $x_offset, $y_offset);
$points[] = $x_offset + $graph_width;
$points[] = $y_offset + $graph_height;
imagepolygon($im, $points, $graph_width + 1, get_color($im, QUOTES_COLOR));

imageline($im, $x_offset, $y_offset, $x_offset, $y_offset + $graph_height, $color);
imageline($im, $x_offset, $y_offset + $graph_height, $x_offset + $graph_width, $y_offset + $graph_height, $color);

imagerectangle($im, 0, 0, IMAGE_WIDTH - 1, IMAGE_HEIGHT - 1, get_color($im, BORDER_COLOR));

$c = get_color($im, TEXT_COLOR);
imagestring($im, FONT_SIZE, $x_offset, $y_offset + $graph_height + TEXT_MARGIN, date(DATE_FORMAT, time() - $total_seconds), $c);
$t = date(DATE_FORMAT);
imagestring($im, FONT_SIZE, $x_offset + $graph_width - strlen($t) * $font_width, $y_offset + $graph_height + TEXT_MARGIN, $t, $c);
imagestringup($im, FONT_SIZE, IMAGE_PADDING, $y_offset + $graph_height, '0', $c);
imagestringup($im, FONT_SIZE, IMAGE_PADDING, IMAGE_PADDING + strlen($max) * $font_width, $max, $c);

header('Content-Type: image/png');
imagepng($im);

function draw_graph ($im, $data, $scale, $imwidth, $imheight, $gwidth, $gheight, $x_offset, $y_offset, $color) {
	$points = to_points($data, $scale, $gwidth, $gheight, $x_offset, $y_offset);
	$points[] = $x_offset + $gwidth;
	$points[] = $y_offset + $gheight;
	$points[] = $x_offset;
	$points[] = $y_offset + $gheight;
	imagefilledpolygon($im, $points, $gwidth + 2, $color);
}

function to_points ($data, $scale, $gwidth, $gheight, $x_offset, $y_offset) {
	$points = array();
	for ($x = 0; $x < $gwidth; $x++) {
		$count = $data[$x];
		$points[] = $x_offset + $x + 1;
		$points[] = round($y_offset + $gheight - $count * $scale);
	}
	return $points;
}

function get_color ($im, $color) {
	$p = explode(',', $color);
	return imagecolorallocatealpha($im, $p[0] + 0, $p[1] + 0, $p[2] + 0, round(($p[3] + 0) / 100 * 127));
}

?>
