<?php

define('MYSQL_HOSTNAME', 'chirpydb.burntelectrons.org');
define('MYSQL_USERNAME', 'chirpydb');
define('MYSQL_PASSWORD', '3arctic3');
define('MYSQL_DATABASE', 'chirpy');
define('MYSQL_TABLE_NAME_PREFIX', '');

?>